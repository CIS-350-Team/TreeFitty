/******************************************
 * Enumeration File for Game Mode.
 * @author Christian Christian Yap
 *******************************************/
public enum GameMode {

    CHECKERSMODE, CONNECTFOURMODE, DEFAULT
	/* Game Modes: CheckerMode, Connect Four, or Default*/
}
